import requests

url = 'http://127.0.0.1:5000/register'
my_data = {
    "name": "Sithu",
    "email": "sithu@test.com",
    "password": "password123"
}

response = requests.post(url, json=my_data)
print(response.text)